﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using LING_Examples.Entities;

namespace LING_Examples.Factories {
	public class Factory {
		public static List<Contact> CreateContactsLazy() {
			var contacts = new List<Contact>();
			for (int i = 0; i < 100; i++) {
				var contact = new Contact();
				contact.LastName = "Perez" + i.ToString(CultureInfo.InvariantCulture);
				contact.FirstName = "Jorge" + i.ToString(CultureInfo.InvariantCulture);
				contact.Id = i;
				contacts.Add(contact);
			}
			return contacts;
		}

		public static List<Phone> CreatePhonesLazy() {
			var phones = new List<Phone>();
			for (int i = 0; i < 100; i++) {
				var phone = new Phone { Number = "111-111" + i.ToString(CultureInfo.InvariantCulture), Type = "Home" + i.ToString(CultureInfo.InvariantCulture), Id = i };
				phones.Add(phone);
			}
			return phones;
		}

		public static List<Address> CreateAddressesLazy() {
			var addresses = new List<Address>();
			for (int i = 0; i < 100; i++) {
				string iStr = i.ToString();
				var address = new Address() { City = "Miami" + iStr, Country = "USA" };
				addresses.Add(address);
			}
			return addresses;
		}

		public static List<Contact> CreateContacts() {
			List<Contact> contacts = new List<Contact>();
			for (int i = 0; i < 100; i++) {
				Contact contact = new Contact();
				contact.LastName = "Perez" + i.ToString(CultureInfo.InvariantCulture);
				contact.FirstName = "Jorge" + i.ToString(CultureInfo.InvariantCulture);
				contact.Id = i;
                contact.Father = new Contact() { FirstName = "Frank", LastName = "Perez", BirthDate = new DateTime(1999,1,1) };
				// create phones
				for (int j = 0; j < 3; j++) {
					Phone phone = new Phone();
					phone.Number = "111-111" + j.ToString(CultureInfo.InvariantCulture);
					contact.Phones.Add(phone);
				}
				// create addresses
				for (int j = 0; j < 4; j++) {
					string zip = string.Empty;
					if (contact.LastName.EndsWith("1"))
						zip = "1111" + j.ToString(CultureInfo.InvariantCulture);
					else {
						zip = "2222" + j.ToString(CultureInfo.InvariantCulture);
					}
					Address address = new Address();
					address.Street = "100 nw 133" + j.ToString(CultureInfo.InvariantCulture);
					address.ZipCode = zip;
					address.City = "Miami" + j.ToString(CultureInfo.InvariantCulture);
					address.Country = "USA" + j.ToString();
					for (int k = 0; k < 5; k++) {
						AddressType addressType = new AddressType();
						addressType.Id = k.ToString();
						addressType.Name = "type" + k.ToString();
						address.AddressType.Add(addressType);
					}
					contact.Addresses.Add(address);
				}
				contacts.Add(contact);
			}
			return contacts;
		}

	}
}
