﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using LING_Examples.Factories;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using LING_Examples.Entities;

namespace LING_Examples {
	/// <summary>
	/// Summary description for UnitTest1
	/// </summary>
	[TestClass]
	public class SelectExamples {
		public SelectExamples() {}
		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext {
			get {
				return testContextInstance;
			}
			set {
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		// [ClassInitialize()]
		// public static void MyClassInitialize(TestContext testContext) { }
		//
		// Use ClassCleanup to run code after all tests in a class have run
		// [ClassCleanup()]
		// public static void MyClassCleanup() { }
		//
		// Use TestInitialize to run code before running each test 
		// [TestInitialize()]
		// public void MyTestInitialize() { }
		//
		// Use TestCleanup to run code after each test has run
		// [TestCleanup()]
		// public void MyTestCleanup() { }
		//
		#endregion

		[TestMethod]
		public void ReturnAddressesWhenZipcodeEqual11111() {
			//List<Contact> contacts = Factory.CreateContacts();
			//Contact oneContact = contacts[0];

			//var results = oneContact.Addresses.Select()(c => c.Addresses).Where(a => a.ZipCode == "11111").Select(a => new { cContactId = a.Id, cZipCode = a.ZipCode });

			//foreach (var item in results)
			//	TestContext.WriteLine("id: " + item.cContactId + " zip: " + item.cZipCode);
			//TestContext.WriteLine("contacts.Count " + contacts.Count);
			//TestContext.WriteLine("results.Count " + results.Count());
			//Assert.AreNotEqual(contacts.Count, results.Count());
		}

	}
}
