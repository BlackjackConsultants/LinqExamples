﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LING_Examples.Entities {
	public class AddressType {
		public string Name {
			get;
			set;
		}

		public string Id {
			get;
			set;
		}
	}
}
