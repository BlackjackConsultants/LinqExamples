﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LING_Examples.Entities {
	public class Phone {
		public string Number {
			get;
			set;
		}
		public string Type {
			get;
			set;
		}
		public int Id {
			get;
			set;
		}
	}
}
